<div class="maincontainer">
    <div class="flex flex-wrap gap-6">
        <div class="card w-96 bg-base-100 shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Web Development Internship Program</h2>
              <ul>
                <li>Duration: 1 month</li>
                <li>Location: Virtual</li>
                <li>Stipend: None</li>
                <li>Start date: 25/10/2023</li>
              </ul>
              <div class="card-actions justify-end">
                <button class="btn btn-primary">View Details</button>
              </div>
            </div>
        </div>
        <div class="card w-96 bg-base-100 shadow-xl">
            <div class="card-body">
              <h2 class="card-title">App Development Internship Program</h2>
              <ul>
                <li>Duration: 1 month</li>
                <li>Location: Virtual</li>
                <li>Stipend: None</li>
                <li>Start date: 25/10/2023</li>
              </ul>
              <div class="card-actions justify-end">
                <button class="btn btn-primary">View Details</button>
              </div>
            </div>
        </div>
        <div class="card w-96 bg-base-100 shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Python Programming Internship Program</h2>
              <ul>
                <li>Duration: 1 month</li>
                <li>Location: Virtual</li>
                <li>Stipend: None</li>
                <li>Start date: 25/10/2023</li>
              </ul>
              <div class="card-actions justify-end">
                <button class="btn btn-primary">View Details</button>
              </div>
            </div>
        </div>
        <div class="card w-96 bg-base-100 shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Java Programming Internship Program</h2>
              <ul>
                <li>Duration: 1 month</li>
                <li>Location: Virtual</li>
                <li>Stipend: None</li>
                <li>Start date: 25/10/2023</li>
              </ul>
              <div class="card-actions justify-end">
                <button class="btn btn-primary">View Details</button>
              </div>
            </div>
        </div>
        <div class="card w-96 bg-base-100 shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Canva Designing Internship Program</h2>
              <ul>
                <li>Duration: 1 month</li>
                <li>Location: Virtual</li>
                <li>Stipend: None</li>
                <li>Start date: 25/10/2023</li>
              </ul>
              <div class="card-actions justify-end">
                <button class="btn btn-primary">View Details</button>
              </div>
            </div>
        </div>
    </div>
</div>

<style>
    .maincontainer {
        margin: 10px 40px 10px 10px;
    }
    .card:hover {
    transform: scale(1.1) translateY(-10px);
    transition: transform 0.2s ease-in-out;
    }

</style>

